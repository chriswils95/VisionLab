from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import pyqtSignal, QThread
import PyQt5.QtCore
import sys
import cv2
import os
from imutils import paths
import face_recognition
import argparse
import pickle
import numpy as np
import time
from train import Train_model
import pickle as dill
import torch
import PIL.Image
from PIL import ImageQt
import torchvision
import torch.nn.functional as F
import torchvision.transforms as transforms
from torch import Tensor
from torch.nn import Linear
from torch.nn import ReLU
from torch.nn import Sigmoid
from torch.nn import Module
from torch.optim import SGD
from torch.nn import BCELoss
from torch.nn.init import kaiming_uniform_
from torch.nn.init import xavier_uniform_
from torch.utils.data import DataLoader
import torch.nn as nn
from torchvision.datasets import CIFAR10



from main import Ui_MainWindow


class App(QtWidgets.QMainWindow, Ui_MainWindow):
 def __init__(self):
   QtWidgets.QMainWindow.__init__(self)
   Ui_MainWindow.__init__(self)
   self.ui = Ui_MainWindow
   self.setupUi(self)
#    pixmap = QPixmap('/home/christopher/NSO_LIFE/Church_leaders/Ardern-Ian-S.jpg')
#    self.image.setPixmap(pixmap)
   self.cap = cv2.VideoCapture(0)
   self.counter = 0
   self.num_files = 115
   self.countLineEdit.setText(str(self.counter))
   self.dataset_values = ["face", "Emotions", "thumbs"]
   self.category_values = {""}
   self.category_array = [["face"], ["smile", "angry", "happy"], ["thumbs up", "thumbs down"]]
   self.datasetComboBox.addItems(self.dataset_values)
   self.datasetComboBox.setCurrentIndex(-1)
   self.add.clicked.connect(self.save)
   self.train.clicked.connect(self.train_ai)
   self.evaluate.clicked.connect(self.evaluate_ai)
   self.faceNameLineEdit.setEnabled(False)
   self.categoryComboBox.setEnabled(False)
   self.datasetComboBox.activated.connect(self.enable_dataset)
   self.categoryComboBox.activated.connect(self.a)
   self.transform = transforms.Compose([
       transforms.ColorJitter(0.2,0.2,0.2,0.2),
       transforms.Resize((224,224)),
       transforms.ToTensor(),
       transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
   ])
   self.apply_training = False
   self.is_face = False
   self.is_ai_train = False
   self.start()
 def a (self):
  self.counter = 0
  self.countLineEdit.setText(str(self.counter))

 def enable_dataset(self):
  self.categoryComboBox.setEnabled(True)
  self.categoryComboBox.clear()
  self.category_values = self.category_array[self.datasetComboBox.currentIndex()]
  self.categoryComboBox.addItems(self.category_values)
  self.train_model = Train_model("/home/christopher/NSO_LIFE/Practice/Datasets", self.category_values)
  if(self.datasetComboBox.currentText() == "face"):
   self.is_face = True
   self.faceNameLineEdit.setEnabled(True)
  else:
     self.is_face = False
     self.faceNameLineEdit.setEnabled(False)


  
 def define_models(self):
   #resnet 34
  self.device = torch.device('cpu')
  self.model = torchvision.models.resnet18(pretrained=True)
  self.model.fc = torch.nn.Linear(512, len(self.train_model.dataset.categories ))
  self.model = self.model.to(self.device)
  self.train_dl = DataLoader(self.train_model.dataset, batch_size=1, shuffle=True)
  return (self.train_dl, self.model)


 def create_if_not_exist(self):
  if not os.path.exists(self.faceNameLineEdit.text()):
    os.makedirs(self.faceNameLineEdit.text())
 def start(self):
  self.timer = QtCore.QTimer()
  self.timer.timeout.connect(self.nextFrameSlot)
  self.timer.start(1000./24)
 def stop(self):
  self.timer.stop()
 
 def save_model(self):
   torch.save(self.model.state_dict(), "/home/christopher/NSO_LIFE/Practice/my_model.pth")
 def load_model(self):
  self.model.load_state_dict(torch.load("/home/christopher/NSO_LIFE/Practice/my_model.pth"))


 def apply_ai_training(self, frame):
  data = pickle.loads(open("/home/christopher/NSO_LIFE/Practice/user_faces.pkl", "rb").read())
  data = np.array(data)
  known_face_encodings = data
  data = pickle.loads(open("/home/christopher/NSO_LIFE/Practice/user_names.pkl", "rb").read())
  known_face_names = data
  face_locations = []
  face_encodings = []
  face_names = []
  process_this_frame = True
  small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
  # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
  rgb_small_frame = small_frame[:, :, ::-1]
  # Only process every other frame of video to save time
  if process_this_frame:
        # Find all the faces and face encodings in the current frame of video
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
        face_names = []
        for face_encoding in face_encodings:
            # See if the face is a match for the known face(s)
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.3)
            name = "Unknown"
            # # If a match was found in known_face_encodings, just use the first one.
            # if True in matches:
            #     first_match_index = matches.index(True)
            #     name = known_face_names[first_match_index]
            # Or instead, use the known face with the smallest distance to the new face
            face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
            counter = 0
            # for i in face_distances:
            #  counter = counter + 1
            #  print("distances at " + str(counter) + ": " + str(i))
            best_match_index = np.argmin(face_distances)
            print(best_match_index)
            if matches[best_match_index]:
                name = known_face_names[best_match_index]
            else:
                name = known_face_names[best_match_index]
            face_names.append(name)
        process_this_frame = not process_this_frame
        for (top, right, bottom, left), name in zip(face_locations, face_names):
        # Scale back up face locations since the frame we detected in was scaled to 1/4 size
         top *= 4
         right *= 4
         bottom *= 4
         left *= 4
        # Draw a box around the face
         cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
        # Draw a label with a name below the face
         cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), cv2.FILLED)
         font = cv2.FONT_HERSHEY_DUPLEX
         cv2.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)
        return frame

 def nextFrameSlot(self):
   ret, self.frame = self.cap.read()
   self.frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
   if(self.apply_training and self.is_face):
    self.frame = self.apply_ai_training(self.frame)
    img = QtGui.QImage(self.frame, self.frame.shape[1], self.frame.shape[0], QtGui.QImage.Format_RGB888)
    pix = QtGui.QPixmap.fromImage(img)
    self.image.setPixmap(pix)
   elif self.is_ai_train:
     self.save_model()
     self.load_model()
     img = QtGui.QImage(self.frame, self.frame.shape[1], self.frame.shape[0], QtGui.QImage.Format_RGB888)
     pix = QtGui.QPixmap.fromImage(img)
     self.image.setPixmap(pix)
    #  self.img = PIL.Image.fromarray(self.frame)
    # #  self.img = self.process_image(self.img)     
    #  self.img = self.transform(self.img)
    #  self.img = self.img.unsqueeze(0)
    #  output = self.model(self.img)
    #  output = F.softmax(output, dim=1).detach().numpy().flatten()
    # #  output = output.detach().numpy()
    #  index = output.argmax()
    #  print("index", index)
    #  in_val = self.train_model.dataset.categories[index]
    #  print("predict val ", in_val)
     self.out_thread = OUTPUT_THREAD()
     self.out_thread.output_data(self.cap, self.transform, self.model)
     self.out_thread.start()
     self.out_thread.my_signal.connect(self.test)
    #  img = QtGui.QImage(self.frame, self.frame.shape[1], self.frame.shape[0], QtGui.QImage.Format_RGB888)
    #  pix = QtGui.QPixmap.fromImage(img)
    #  self.image.setPixmap(pix)

   else:
    img = QtGui.QImage(self.frame, self.frame.shape[1], self.frame.shape[0], QtGui.QImage.Format_RGB888)
    pix = QtGui.QPixmap.fromImage(img)
    self.image.setPixmap(pix)
 def test(self, value):
   print("Value ", value) 
 def save(self):
   self.frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
   if(self.is_face):
    self.create_if_not_exist()
    cv2.imwrite("/home/christopher/NSO_LIFE/Practice/" + self.faceNameLineEdit.text() + "/" + self.countLineEdit.text() + ".jpeg", self.frame)
   else:
     self.train_model.dataset.save_entry(self.frame, self.categoryComboBox.currentText())
   self.counter += 1
   self.countLineEdit.setText(str(self.counter))

 def update_progress(self, value):
   self.progressBar.setValue(value)
  #  if(value == 5):
 def train_ai(self):
   self.progressBar.setMaximum(len(self.category_values) * self.counter)
   self.thread = UI_Thread()
   self.thread.set_is_torch(False)
   self.thread.set_user_directory(self.faceNameLineEdit.text())
   if(not self.is_face):
     self.thread.set_is_torch(True)
     self.train_del, self.model = self.define_models()
     self.thread.set_model(self.model, self.train_dl)
   self.thread.start()
   self.thread.my_signal.connect(self.update_progress)

 def evaluate_ai(self):
   self.apply_training = True
   if(not self.is_face):
     self.is_ai_train = True
   else:
     self.is_ai_train = False

class UI_Thread(QThread):
  
   my_signal = pyqtSignal(int)
   is_torch = False
   model = ""
   train_dl = ""
   user_directory = ""
   def run(self):
    counter = 0
    if(self.is_torch):
      device = torch.device('cpu')
      optimizer = torch.optim.Adam(self.model.parameters())
      self.model = self.model.train()
      criterion = BCELoss()
      # enumerate epochs
      for epoch in range(2):
        # enumerate mini batches
        sum_loss = 0.0
        error_count = 0.0
        i = 0
        for images, labels in iter(self.train_dl):
            # clear the gradients geget
            images = images.to(device)
            labels = labels.to(device)
            optimizer.zero_grad()
            outputs = self.model(images)
            print(outputs)
            loss = F.cross_entropy(outputs, labels)
            # torch.autograd.set_detect_anomaly(True)
            loss.backward()
            optimizer.step()
            count = len(labels.flatten())
            counter += 1
            error_count += len(torch.nonzero(outputs.argmax(1) - labels).flatten())
            print("error count", error_count)
            i += count
            sum_loss += float(loss)
            accuracy = 1.0 - error_count / i
            # counter = counter / len(self.train_dl)
            print("accuracy ", accuracy)
            self.my_signal.emit(counter)
    else:
     data = []
     names = []
     sPath = "/home/christopher/NSO_LIFE/Practice/" + self.user_directory
     for roots, dirs, files in os.walk(sPath):
      for file in files:
       counter += 1
       print("[INFO] processing image {}/{}".format(counter, len(files)))
       encodings = self.get_encodings(file, sPath)
       if(encodings != ''):
        print("in here")
        data.append(encodings)
       file = file[:-1]
       file = file[:-1]
       file = file[:-1]
       file = file[:-1]
       print(file)
       if (encodings != ''):
        names.append(self.user_directory)
       self.my_signal.emit(counter)
     with open('user_faces.pkl', 'ab') as f:
      dill.dump(data, f)
     with open('user_names.pkl', 'ab') as d:
      dill.dump(names, d)
    print("done")
   
   def set_user_directory(self, directory):
    self.user_directory = directory
  
   def set_model(self, value, train_dl):
     self.model = value
     self.train_dl = train_dl
   def set_is_torch(self, value):
     self.is_torch = value
   def get_encodings(self, file, sPath):
    image = face_recognition.load_image_file(sPath + "/" + file)
    encodings = face_recognition.face_encodings(image)
    if len(encodings) > 0:
     encodings = encodings[0]
    else:
     height, width, _ = image.shape
     # location is in css order - top, right, bottom, left
    #  face_location = (0, width, height, 0)
    #  encodings = face_recognition.face_encodings(image, known_face_locations=[face_location])  
     print("No face found")
     return ""
    return encodings
      

class OUTPUT_THREAD(QThread):
  my_signal = pyqtSignal(int)
  # output = 0
  cap = None
  # image = None
  transform = None
  model = None
  def output_data(self,frame, transform, model):
    # self.output = output
    self.cap = frame
    self.transform = transform
    self.model = model
    # self.image = image
  def run(self):
    counter = 0
    ret, self.frame = self.cap.read()
    self.frame = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
    self.img = PIL.Image.fromarray(self.frame)
    img = QtGui.QImage(self.frame, self.frame.shape[1], self.frame.shape[0], QtGui.QImage.Format_RGB888)
    pix = QtGui.QPixmap.fromImage(img)
    self.image.setPixmap(pix)
    #  self.img = self.process_image(self.img)     
    self.img = self.transform(self.img)
    self.img = self.img.unsqueeze(0)
    output = self.model(self.img)
    output = F.softmax(output, dim=1).detach().numpy().flatten()
    #  output = output.detach().numpy()
    index = output.argmax()
    print("index", index)
    # in_val = self.train_model.dataset.categories[index]
    # print("predict val ", in_val)
    for i, score in enumerate(list(output)):
        # img = QtGui.QImage(self.frame, self.frame.shape[1], self.frame.shape[0], QtGui.QImage.Format_RGB888)
        # pix = QtGui.QPixmap.fromImage(img)
        # self.image.setPixmap(pix)
        self.my_signal.emit(score)
if __name__ == '__main__':
  app = QApplication(sys.argv)
  form = App()
  form.show()
  app.exec_()